
package Modelo;


public class Product {
    //atributos
    private String Tipo;
    private String Especificaciones;
    private String nombre;
    private int cantidad;
    private String Durabilidad;
    private int ID;
    private int IDTipo;
    private int PrecioC;
    private int precioU;
    private double subT;
    private double IVA;
    private double retefuente;
    private double total;

    public Product() {
         //To change body of generated methods, choose Tools | Templates.
    }

    public String getTipo() {
        return Tipo;
    }

    public String getEspecificaciones() {
        return Especificaciones;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getDurabilidad() {
        return Durabilidad;
    }

    public int getID() {
        return ID;
    }

    public int getIDTipo() {
        return IDTipo;
    }

    public int getPrecioC() {
        return PrecioC;
    }

    public int getPrecioU() {
        return precioU;
    }

    public double getSubT() {
        return subT;
    }

    public double getIVA() {
        return IVA;
    }

    public double getRetefuente() {
        return retefuente;
    }

    public double getTotal() {
        return total;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public void setEspecificaciones(String Especificaciones) {
        this.Especificaciones = Especificaciones;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setDurabilidad(String Durabilidad) {
        this.Durabilidad = Durabilidad;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setIDTipo(int IDTipo) {
        this.IDTipo = IDTipo;
    }

    public void setPrecioC(int PrecioC) {
        this.PrecioC = PrecioC;
    }

    public void setPrecioU(int precioU) {
        this.precioU = precioU;
    }

    public void setSubT(double subT) {
        this.subT = subT;
    }

    public void setIVA(double IVA) {
        this.IVA = IVA;
    }

    public void setRetefuente(double retefuente) {
        this.retefuente = retefuente;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Product(String Tipo, String Especificaciones, String nombre, int cantidad, String Durabilidad, int ID, int IDTipo, int PrecioC, int precioU, double subT, double IVA, double retefuente, double total) {
        this.Tipo = Tipo;
        this.Especificaciones = Especificaciones;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.Durabilidad = Durabilidad;
        this.ID = ID;
        this.IDTipo = IDTipo;
        this.PrecioC = PrecioC;
        this.precioU = precioU;
        this.subT = subT;
        this.IVA = IVA;
        this.retefuente = retefuente;
        this.total = total;
    }
    
    
}
